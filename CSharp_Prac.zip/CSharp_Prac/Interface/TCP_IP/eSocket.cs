﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;

namespace CSharp_Prac.Interface.TCP_IP
{
    class eSocket
    {
        private Socket _socket;
        public eSocket()
        {
            init();
        }
        private void init()
        {

        }
    }
}
